// Dicoding: Belajar Membuat Aplikasi Android untuk Pemula
// Views and ViewGroup
// 10214037 Muhammad Naufal Ghifari
// GitHub DC17MNG
// Created on 2019, August 1st

package com.example.mng_myviewandviews;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Google Pixel");
        }
    }
}
